__author__ = 'chandrashekhar'
s=raw_input("enter the string:")
if s == "": print(0)
print(s.rindex(s[-1])+1)



