"""lst=raw_input('enter your list:')
lst=eval(lst)
print(min(lst))
print(max(lst))"""
string_input=raw_input("enter your list:")
input_list=string_input.split()
input_list=[int(a)for a in input_list]
print(input_list)
min=input_list[0]
for i in input_list[1:]:
    if min>i:
        min=i
print(min)
max=input_list[0]
for i in input_list[1:]:
    if i>max:
        max=i
print max