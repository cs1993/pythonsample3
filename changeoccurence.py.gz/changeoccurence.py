__author__ = 'chandrashekhar'
str = raw_input("enter the string:")
s = str[0]
strL=list(str)
for i in range(len(strL)):
    if i>0:
        if s==strL[i]:
            strL[i]='$'
str="".join(strL)
print(str)
