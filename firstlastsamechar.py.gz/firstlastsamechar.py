__author__ = 'chandrashekhar'
string_input=raw_input("enter your list:")
input_list=string_input.split()
count=0
for str in input_list:
    if len(str)>2:
        if str[0]==str[len(str)-1]:
            count=count+1
print count
