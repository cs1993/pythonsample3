length=0
str=raw_input("enter the string:")
for i in str:
    length+=1
print(length)
