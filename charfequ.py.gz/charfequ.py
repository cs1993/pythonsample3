__author__ = 'chandrashekhar'
str=raw_input("enter the string:")
from collections import Counter
print Counter(str)
