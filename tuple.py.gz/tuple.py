__author__ = 'chandrashekhar'

from ast import literal_eval

cns=literal_eval(raw_input("please enter the data:"))

print sorted(cns,key=lambda cns:cns[1])
