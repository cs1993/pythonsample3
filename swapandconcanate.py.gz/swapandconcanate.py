__author__ = 'chandrashekhar'
s1=raw_input("please enter first string:")
s2=raw_input("please enter second string:")
s=s1[0:2]
sl1=list(s1)
sl2=list(s2)
sl1[0:2]=sl2[0:2]
sl2[0:2]=s
s=[' ']
sl3=sl1+s+sl2
print ''.join(sl3)

