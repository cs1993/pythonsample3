__author__ = 'chandrashekhar'
list=[3,4,1,20,102,3,5,67,39,28,10,1,4,34,1,6,107,99]
print (list)
print(min(list))
print(max(list))
