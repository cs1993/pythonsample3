__author__ = 'chandrashekhar'
s=raw_input("please enter the string:")
sl=list(s)
if(len(sl)>=3):
    if sl[-3:len(sl)]==['i','n','g']:
        sl=sl+['l','y']
    else:
        sl=sl+['i','n','g']
    s=''.join(sl)
    print s

else:
    print("string  size is less three")