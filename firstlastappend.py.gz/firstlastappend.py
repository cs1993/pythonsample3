__author__ = 'chandrashekhar'
str=raw_input("enter the string:")
if len(str)>=2:
    str1=str[0:2]+str[-2:len(str)]
    print str1
else:
    print("empty string")

