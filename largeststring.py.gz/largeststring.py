__author__ = 'chandrashekhar'
list=raw_input("enter the  no of string you want: ")
list=list.split()
large=list[0]
for i in list:
    if(len(large)<len(i)):
        large=i
print(large,len(large))

